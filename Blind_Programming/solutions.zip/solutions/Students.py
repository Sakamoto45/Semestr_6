from math import floor
print(floor((int(input()) * 3 - 2) / 4))