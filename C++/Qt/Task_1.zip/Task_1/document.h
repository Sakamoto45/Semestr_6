#ifndef DOCUMENT_H
#define DOCUMENT_H


class Document
{
private:
    int i;

public:
    Document();
    ~Document();

    int getI();
    void setup();

};

#endif // DOCUMENT_H
