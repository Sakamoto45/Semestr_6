#include "document.h"

Document::Document()
{

}

Document::~Document()
{

}

int Document::getI()
{
    return i;
}

void Document::setup()
{
    i = 100;
}
