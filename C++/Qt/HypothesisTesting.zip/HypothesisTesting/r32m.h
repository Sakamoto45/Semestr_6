#pragma once

#include <math.h>

void rninit(unsigned long iufir);
void rnrest();
void rnconst(unsigned long iufir);
void rnconfix(unsigned nmb);

unsigned long rnfirst();
unsigned long rnlast();
unsigned long rnconrd();

double rnunif();
double rnexp();
double rnnorm();
